// 导入css文件
// require('../statics/a.less') //es5
import '../statics/a.less';